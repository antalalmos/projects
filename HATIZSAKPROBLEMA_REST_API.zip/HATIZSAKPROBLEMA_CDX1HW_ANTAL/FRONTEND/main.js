document.getElementById("knapsack-form").addEventListener("submit", async function (e) {
    e.preventDefault();

    const capacity = parseInt(document.getElementById("capacity").value);
    const itemsText = document.getElementById("items").value.trim();

    if (!itemsText || isNaN(capacity) || capacity <= 0) {
        alert("Kérlek, adj meg érvényes bemenetet!");
        return;
    }

    const lines = itemsText.split("\n").map(line => line.trim()).filter(line => line !== "");
    const items = [];

    for (let line of lines) {
        const parts = line.split(",").map(p => p.trim());
        if (parts.length !== 3) {
            alert("Hibás sor: " + line);
            return;
        }
        const [name, sizeStr, valueStr] = parts;
        const size = parseInt(sizeStr);
        const value = parseInt(valueStr);

        if (!name || isNaN(size) || isNaN(value)) {
            alert("Hibás adat: " + line);
            return;
        }

        items.push({ name, size, value });
    }

    const inputData = {
        Capacity: capacity,
        Items: items
    };

    try {
        const response = await fetch("http://localhost:5196/itemapi/optimalis", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(inputData)
        });

        if (!response.ok) throw new Error("Hiba a kiszolgálón: " + response.status);

        const data = await response.json();
        renderResult(data, capacity);
    } catch (err) {
        console.error(err);
        alert("Hiba történt a kérés feldolgozása közben.");
    }
});

function renderResult(data, capacity) {
    const { valasztottTargyak, vizualisCellak, teljesErtek } = data;

    // Összérték megjelenítése
    document.getElementById("total-value").textContent = teljesErtek;

    // Legenda generálása
    const legend = document.getElementById("legend");
    legend.innerHTML = "";
    valasztottTargyak.forEach(item => {
        const badge = document.createElement("span");
        badge.className = "badge p-2 text-white";
        badge.style.backgroundColor = item.szin;
        badge.textContent = `${item.nev} (${item.meret}, ${item.ertek})`;
        legend.appendChild(badge);
    });

    // Táblázat generálása (5 sor, capacity / 5 oszlop)
    const tableWrapper = document.getElementById("table-wrapper");
    tableWrapper.innerHTML = "";

    const table = document.createElement("table");
    table.className = "table table-bordered text-center";
    const tbody = document.createElement("tbody");

    const columns = Math.ceil(capacity / 5);
    let index = 0;
    for (let row = 0; row < 5; row++) {
        const tr = document.createElement("tr");
        for (let col = 0; col < columns; col++) {
            const td = document.createElement("td");
            if (index < vizualisCellak.length) {
                const nev = vizualisCellak[index];
                const item = valasztottTargyak.find(i => i.nev === nev);
                td.style.backgroundColor = item ? item.szin : "#eee";
                td.textContent = nev.charAt(0).toUpperCase();
            } else {
                td.textContent = "";
            }
            tr.appendChild(td);
            index++;
        }
        tbody.appendChild(tr);
    }

    table.appendChild(tbody);
    tableWrapper.appendChild(table);

    // Megjelenítés bekapcsolása
    document.getElementById("result-section").style.display = "block";
}
