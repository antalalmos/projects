﻿using HATIZSAKPROBLEMA_CDX1HW_ANTAL.Models;

namespace HATIZSAKPROBLEMA_CDX1HW_ANTAL.Data
{
    public interface IBPItemRepository
    {
        void Create(BPItem item);
        void Delete(string name);
        IEnumerable<BPItem> Read();
        BPItem? Read(string name);
        void Update(BPItem item);
    }
}