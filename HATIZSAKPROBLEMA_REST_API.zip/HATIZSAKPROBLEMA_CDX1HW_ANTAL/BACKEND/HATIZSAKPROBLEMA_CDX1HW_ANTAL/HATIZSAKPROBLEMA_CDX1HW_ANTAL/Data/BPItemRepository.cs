﻿using HATIZSAKPROBLEMA_CDX1HW_ANTAL.Models;

namespace HATIZSAKPROBLEMA_CDX1HW_ANTAL.Data
{
    public class BPItemRepository : IBPItemRepository
    {
        List<BPItem> items;

        public BPItemRepository()
        {
            items = new List<BPItem>();
        }

        public void Create(BPItem item)
        {
            this.items.Add(item);
        }

        public IEnumerable<BPItem> Read()
        {
            return this.items;
        }

        public BPItem? Read(string name)
        {
            //BPItem names are unique
            return this.items.FirstOrDefault(x => x.Name == name);
        }

        public void Update(BPItem item)
        {
            BPItem toUpdate = this.Read(item.Name);

            toUpdate.Size = item.Size;
            toUpdate.Value = item.Value;
        }

        public void Delete(string name)
        {
            BPItem toDelete = this.Read(name);

            this.items.Remove(toDelete);
        }
    }
}
