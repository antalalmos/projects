﻿//using HATIZSAKPROBLEMA_CDX1HW_ANTAL.Data;
//using HATIZSAKPROBLEMA_CDX1HW_ANTAL.Models;
//using Microsoft.AspNetCore.Mvc;

//namespace HATIZSAKPROBLEMA_CDX1HW_ANTAL.Controllers
//{
//    [ApiController]
//    [Route("[controller]")]
//    public class ItemApiController : ControllerBase
//    {

//        public ItemApiController()
//        {
//        }

//    }
//}

using HATIZSAKPROBLEMA_CDX1HW_ANTAL.Models;
using Microsoft.AspNetCore.Mvc;

namespace HATIZSAKPROBLEMA_CDX1HW_ANTAL.Controllers
{
    [ApiController]
    [Route("itemapi")]
    public class ItemApiController : ControllerBase
    {
        [HttpPost("optimalis")]
        public IActionResult GetOptimalPacking([FromBody] BPInput input)
        {
            if (input == null || input.Items == null || input.Capacity <= 0)
            {
                return BadRequest("Hibás bemenet.");
            }

            var result = SolveKnapsack(input.Items, input.Capacity);
            return Ok(result);
        }

        private object SolveKnapsack(List<BPItem> items, int capacity)
        {
            int n = items.Count;
            int[,] dp = new int[n + 1, capacity + 1];

            for (int i = 1; i <= n; i++)
            {
                for (int w = 0; w <= capacity; w++)
                {
                    if (items[i - 1].Size > w)
                        dp[i, w] = dp[i - 1, w];
                    else
                        dp[i, w] = Math.Max(dp[i - 1, w], dp[i - 1, w - items[i - 1].Size] + items[i - 1].Value);
                }
            }

            List<BPItem> selectedItems = new();
            int res = dp[n, capacity];
            int wgt = capacity;
            for (int i = n; i > 0 && res > 0; i--)
            {
                if (res != dp[i - 1, wgt])
                {
                    selectedItems.Add(items[i - 1]);
                    res -= items[i - 1].Value;
                    wgt -= items[i - 1].Size;
                }
            }

            string[] szinek = { "#e6194b", "#3cb44b", "#ffe119", "#4363d8", "#f58231", "#911eb4", "#46f0f0", "#f032e6", "#bcf60c" };
            var itemColorMap = new Dictionary<string, string>();
            for (int i = 0; i < selectedItems.Count; i++)
            {
                itemColorMap[selectedItems[i].Name] = szinek[i % szinek.Length];
            }

            List<string> visualCells = new();
            foreach (var item in selectedItems)
            {
                for (int i = 0; i < item.Size; i++)
                {
                    visualCells.Add(item.Name);
                }
            }

            return new
            {
                teljesErtek = dp[n, capacity],
                valasztottTargyak = selectedItems.Select(i => new
                {
                    nev = i.Name,
                    meret = i.Size,
                    ertek = i.Value,
                    szin = itemColorMap[i.Name]
                }),
                vizualisCellak = visualCells
            };
        }
    }
}

