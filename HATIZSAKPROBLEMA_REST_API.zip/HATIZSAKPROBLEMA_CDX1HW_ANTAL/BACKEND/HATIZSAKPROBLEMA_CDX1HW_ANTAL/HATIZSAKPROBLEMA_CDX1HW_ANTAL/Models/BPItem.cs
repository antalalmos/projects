﻿namespace HATIZSAKPROBLEMA_CDX1HW_ANTAL.Models
{
    public class BPItem
    {
        public string Name { get; set; }

        public int Size { get; set; }

        public int Value { get; set; }
    }
}
