﻿namespace HATIZSAKPROBLEMA_CDX1HW_ANTAL.Models
{
    public class BPInput
    {
        public int Capacity { get; set; }

        public List<BPItem> Items { get; set; }
    }
}
