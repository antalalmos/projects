//using HATIZSAKPROBLEMA_CDX1HW_ANTAL.Data;

//var builder = WebApplication.CreateBuilder(args);

//// Add services to the container.

//builder.Services.AddControllersWithViews();
//// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
////builder.Services.AddEndpointsApiExplorer();
////builder.Services.AddSwaggerGen();

//builder.Services.AddSingleton<IBPItemRepository, BPItemRepository>();

//var app = builder.Build();

////// Configure the HTTP request pipeline.
////if (app.Environment.IsDevelopment())
////{
////    app.UseSwagger();
////    app.UseSwaggerUI();
////}

//app.UseRouting();

//app.MapControllers();

//app.MapControllerRoute(name: "default", pattern: "{controller}/{action=Index}/{id?}");

////app.UseAuthorization();

////app.MapControllers();

//app.MapGet("/", () => "Hello World!");

//app.UseCors(x => x
//    .AllowCredentials()
//    .AllowAnyMethod()
//    .AllowAnyHeader()
//    .WithOrigins("http://localhost:5500"));

//app.Run();

var builder = WebApplication.CreateBuilder(args);

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowLocalhost",
        policy => policy.WithOrigins("http://127.0.0.1:5500")
                        .AllowAnyHeader()
                        .AllowAnyMethod());
});

builder.Services.AddControllers();

var app = builder.Build();

app.UseCors("AllowLocalhost");
app.UseAuthorization();
app.MapControllers();
app.Run();